import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login and Sign Up',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),
      routes: {
        '/signup': (context) => SignUpPage(),
        '/home': (context) => HomePage(),
      },
    );
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Log In your Account',
              style: TextStyle(
                fontSize: 50.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Username',
                filled: true,
                fillColor: Colors.yellow[200],
              ),
              style: TextStyle(
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
                filled: true,
                fillColor: Colors.yellow[200],
              ),
              obscureText: true,
              style: TextStyle(
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 50.0),
            ClipOval(
              child: ElevatedButton(
                child: Text('Login'),
                onPressed: () {
                  // Perform login logic here
                  String username = _usernameController.text;
                  String password = _passwordController.text;
                  // Validate username and password

                  // If validation succeeds, navigate to home page
                  Navigator.pushReplacementNamed(context, '/home');
                },
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all<Color>(Colors.black),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            ClipOval(
              child: TextButton(
                child: Text('Haven\'t created your account yet? Create now!'),
                onPressed: () {
                  // Navigate to sign up page
                  Navigator.pushNamed(context, '/signup');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SignUpPage extends StatelessWidget {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _retypePasswordController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign Up'),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Create Your Account',
              style: TextStyle(
                fontSize: 50.0,
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email Address',
                filled: true,
                fillColor: Colors.yellow[200],
              ),
              style: TextStyle(
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Username',
                filled: true,
                fillColor: Colors.yellow[200],
              ),
              style: TextStyle(
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
                filled: true,
                fillColor: Colors.yellow[200],
              ),
              obscureText: true,
              style: TextStyle(
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _retypePasswordController,
              decoration: InputDecoration(
                labelText: 'Re-type Password',
                filled: true,
                fillColor: Colors.yellow[200],
              ),
              obscureText: true,
              style: TextStyle(
                fontFamily: 'Times New Roman',
              ),
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              child: Text(
                'Create',
                style: TextStyle(
                  fontFamily: 'Times New Roman',
                  color: Colors.black,
                ),
              ),
              onPressed: () {
                // Perform sign up logic here
                String email = _emailController.text;
                String username = _usernameController.text;
                String password = _passwordController.text;
                String retypePassword = _retypePasswordController.text;
                // Validate email, username, password, and retypePassword

                // If validation succeeds, navigate back to login page
                Navigator.pop(context);
              },
              style: ButtonStyle(
                textStyle: MaterialStateProperty.all<TextStyle>(
                  TextStyle(
                    fontFamily: 'Times New Roman',
                  ),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            Text(
              'In good writing, words become one with things. All good writing leaves something unexpressed.',
              style: TextStyle(
                color: Colors.grey,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final TextEditingController _textEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(8.0),
                  color: Colors.yellow[100],
                ),
                child: TextField(
                  controller: _textEditingController,
                  maxLines: null,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Write something...',
                    hintStyle: TextStyle(
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                  style: TextStyle(
                    fontSize: 16.0,
                  ),
                ),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              child: Text(
                'Save',
                style: TextStyle(
                  fontFamily: 'Times New Roman',
                  color: Colors.white,
                ),
              ),
              onPressed: () {
                // Save the content of the notepad
                String content = _textEditingController.text;
                // Perform save logic here (e.g., store in a database, file, etc.)
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Saved'),
                      content: Text('Content saved successfully.'),
                      actions: [
                        TextButton(
                          child: Text('OK'),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ],
                    );
                  },
                );
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.black),
                textStyle: MaterialStateProperty.all<TextStyle>(
                  TextStyle(
                    fontFamily: 'Times New Roman',
                  ),
                ),
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              child: Text(
                'Sign Out',
                style: TextStyle(
                  fontFamily: 'Times New Roman',
                  color: Colors.white,
                ),
              ),
              onPressed: () {
                Navigator.pop(context); // Return to the login page
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.black),
                textStyle: MaterialStateProperty.all<TextStyle>(
                  TextStyle(
                    fontFamily: 'Times New Roman',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
