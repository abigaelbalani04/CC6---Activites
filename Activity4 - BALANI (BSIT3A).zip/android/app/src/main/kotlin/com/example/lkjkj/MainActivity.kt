package com.example.lkjkj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
