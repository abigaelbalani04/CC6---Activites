import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Calculator',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  TextEditingController _textEditingController = TextEditingController();
  double _result = 0;

  @override
  void dispose() {
    _textEditingController.dispose();
    super.dispose();
  }

  void calculateResult(String operation) {
    double input = double.tryParse(_textEditingController.text) ?? 0;

    setState(() {
      switch (operation) {
        case '+':
          _result += input;
          break;
        case '-':
          _result -= input;
          break;
        case '*':
          _result *= input;
          break;
        case '/':
          _result /= input;
          break;
      }

      _textEditingController.text = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
        backgroundColor: Colors.red,
      ),
      body: Column(
        children: [
          TextField(
            controller: _textEditingController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Enter a number',
            ),
          ),
          SizedBox(height: 50),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                child: Text('+'),
                onPressed: () => calculateResult('+'),
              ),
              ElevatedButton(
                child: Text('-'),
                onPressed: () => calculateResult('-'),
              ),
              ElevatedButton(
                child: Text('*'),
                onPressed: () => calculateResult('*'),
              ),
              ElevatedButton(
                child: Text('/'),
                onPressed: () => calculateResult('/'),
              ),
            ],
          ),
          SizedBox(height: 20),
          Text(
            'Result: ${_result.toStringAsFixed(2)}',
            style: TextStyle(fontSize: 24),
          ),
        ],
      ),
    );
  }
}
